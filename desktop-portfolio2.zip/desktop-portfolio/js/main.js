/* Shreya Jagtap: interactive desktop portfolio. No build step, no dependencies.
   Structure: helpers > desktop > chapter builders > chapter shell > recruiter > routing. */
(function () {
  "use strict";
  var S = window.SITE;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var RM = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var FINE = window.matchMedia("(pointer: fine)").matches;
  var desk = $("#desk"), chapterEl = $("#chapter"), body = $("#chapter-body"), recEl = $("#recruiter");
  var fixed = [$(".chrome"), desk, $(".dock")];
  var current = null, sound = false, actx = null, lastFocus = null, io = null, run = 0;
  var seq = S.chapters.filter(function (c) { return !c.hidden; });
  var byId = function (id) { return S.chapters.filter(function (c) { return c.id === id; })[0]; };
  var wait = function (ms) { return new Promise(function (r) { setTimeout(r, RM ? 0 : ms); }); };
  var esc = function (t) { return String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;"); };

  /* ---------- sound (off by default) ---------- */
  function blip(freq, dur) {
    if (!sound) return;
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      var o = actx.createOscillator(), g = actx.createGain();
      o.type = "square"; o.frequency.value = freq || 520; g.gain.value = 0.025;
      o.connect(g); g.connect(actx.destination); o.start();
      g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + (dur || 0.06));
      o.stop(actx.currentTime + (dur || 0.06));
    } catch (e) {}
  }
  $("#btn-sound").addEventListener("click", function () {
    sound = !sound; this.textContent = sound ? "Sound on" : "Sound off"; this.setAttribute("aria-pressed", sound); blip(660);
  });

  /* ---------- desktop ---------- */
  $(".h-role").textContent = S.role;
  $("#tagline").textContent = S.tagline;
  $("#tags").innerHTML = S.tags.map(function (t) {
    return '<li style="left:' + t.x + "%;top:" + t.y + '%"><i style="background:' + t.color + '"></i>' + esc(t.text) + "</li>";
  }).join("");

  function folderSVG(color) {
    return '<svg viewBox="0 0 120 92" aria-hidden="true"><path d="M6 14q0-8 8-8h30l10 10h52q8 0 8 8v56q0 8-8 8H14q-8 0-8-8z" fill="' + color + '" fill-opacity=".75"/>' +
      '<path class="flap" d="M6 30q0-8 8-8h92q8 0 8 8v46q0 8-8 8H14q-8 0-8-8z" fill="' + color + '"/></svg>';
  }
  var ARROW = '<svg class="arrow" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 2l14 12-6.5.8L16 22l-3 1.2-3.4-7.3L5 20z" fill="#171717" stroke="#fff" stroke-width="1.2"/></svg>';
  var list = $("#folders");
  S.chapters.filter(function (c) { return c.pos; }).forEach(function (c, i) {
    var li = document.createElement("li");
    li.style.cssText = "--x:" + c.pos.x + ";--y:" + c.pos.y + ";--d:" + c.pos.d + ";--r:" + c.pos.r + ";--i:" + i;
    var icon = c.thumb ? '<span class="thumb"><img src="' + c.thumb + '" alt="" width="120" height="120"></span>' : folderSVG(c.id === "next" ? "#8f8a82" : c.color === "#171717" ? "#8BA6B9" : c.color);
    li.innerHTML = '<button class="folder' + (c.selected ? " sel" : "") + '" type="button" data-id="' + c.id + '">' + icon +
      '<span class="lbl">' + esc(c.file) + "</span>" + (c.selected ? ARROW : "") + "</button>";
    list.appendChild(li);
  });
  var nFolders = list.children.length;
  S.boot.forEach(function (t, i) {
    setTimeout(function () { var li = document.createElement("li"); li.textContent = t.replace("{n}", nFolders); $("#boot").appendChild(li); }, RM ? 0 : 600 + i * 600);
  });
  if (FINE && !RM) {
    desk.addEventListener("pointermove", function (e) {
      var r = desk.getBoundingClientRect();
      desk.style.setProperty("--nx", ((e.clientX - r.left) / r.width * 2 - 1).toFixed(3));
      desk.style.setProperty("--ny", ((e.clientY - r.top) / r.height * 2 - 1).toFixed(3));
    });
    var cur = $("#cursor"), cx = 0, cy = 0, tx = 0, ty = 0;
    window.addEventListener("pointermove", function (e) { tx = e.clientX; ty = e.clientY; cur.classList.add("on"); cur.classList.toggle("big", !!e.target.closest("button,a")); });
    (function loop() { cx += (tx - cx) * 0.18; cy += (ty - cy) * 0.18; cur.style.left = cx + "px"; cur.style.top = cy + "px"; requestAnimationFrame(loop); })();
  }
  list.addEventListener("click", function (e) { var b = e.target.closest(".folder"); if (b) { e.stopPropagation(); blip(440); go(b.dataset.id); } });
  desk.addEventListener("click", function (e) { if (!e.target.closest("button,a")) go("now"); });
  $("#btn-begin").addEventListener("click", function (e) { e.stopPropagation(); go("now"); });

  /* ---------- builders ---------- */
  function label(t) { return '<p class="label reveal">' + esc(t) + "</p>"; }
  function lines(arr) { return arr && arr.length ? '<div class="c-lines">' + arr.map(function (l, i) { return '<p class="lr"><span style="transition-delay:' + i * 0.15 + 's">' + esc(l) + "</span></p>"; }).join("") + "</div>" : ""; }
  function facts(arr) { return arr ? label("Key facts") + '<dl class="facts reveal">' + arr.map(function (f) { return "<div><dt>" + esc(f[0]) + "</dt><dd>" + esc(f[1]) + "</dd></div>"; }).join("") + "</dl>" : ""; }
  function link(l) { return l ? '<p class="links reveal"><a href="' + l.href + '" rel="noopener">' + esc(l.label) + "</a></p>" : ""; }
  function head(c) {
    var h = '<header class="c-head' + (c.hero ? " has-hero hero-" + c.hero.style : "") + '"><p class="kicker">' + esc(c.kicker) + "</p>" +
      '<h2 class="ctitle"><img src="assets/type/' + c.word + '.webp" alt="' + esc(c.title) + '"></h2>';
    if (c.hero) {
      h += '<figure class="c-hero dev"><img src="' + c.hero.src + '" alt="' + esc(c.hero.alt) + '">' + (c.hero.caption ? '<figcaption class="mono">' + esc(c.hero.caption) + "</figcaption>" : "") + "</figure>";
    }
    return h + "</header>";
  }
  function nextBlock(c) {
    var i = seq.indexOf(c), n = i > -1 ? seq[i + 1] : null;
    if (n) return '<div class="next"><button class="big" type="button" data-go="' + n.id + '"><small>Next file</small>' + esc(n.file) + "</button></div>";
    return '<div class="next"><button class="big" type="button" data-go="home"><small>Done here</small>Back to desktop</button></div>';
  }
  function linkRow() {
    return '<p class="links"><a href="' + S.linkedin + '" rel="noopener">LinkedIn</a><a href="' + S.github + '" rel="noopener">GitHub</a><a href="' + S.cv + '" download>Download CV</a><a href="mailto:' + S.email + '">Email</a></p>';
  }

  var special = {
    now: function () { return '<div class="term reveal" data-hook="terminal"><div class="tb"><i></i><i></i><i></i></div><div id="term-out"></div></div>'; },
    telus: function (c) {
      return label("Progression") + '<div class="flow" data-hook="flow">' + c.flow.map(function (f, i) {
        return '<div><p class="mono">(' + (i + 1) + ") " + esc(f.when) + "</p><h3>" + esc(f.step) + "</h3><p><b>" + esc(f.role) + "</b></p><p>" + esc(f.text) + "</p></div>";
      }).join("") + "</div>" +
        label("Results") + '<div class="metrics" data-hook="metrics">' + c.metrics.map(function (x) {
        return '<div class="metric"><b data-from="' + (x.from || 0) + '" data-to="' + x.to + '" data-suffix="' + x.suffix + '">' + (x.from || 0) + x.suffix + "</b><span>" + esc(x.label) + "</span><small>" + esc(x.note) + "</small></div>";
      }).join("") + "</div>" +
        label("Areas of work") + '<ul class="chips reveal">' + c.chips.map(function (t) { return "<li><i></i>" + esc(t) + "</li>"; }).join("") + "</ul>" + link(c.link);
    },
    mba: function (c) {
      return label("Thesis") + '<div class="doc" data-hook="doc"><span class="tab">thesis.pdf</span><p class="mono">Master\'s thesis, LBTU, 2026</p><h3>' + esc(c.thesis) + "</h3>" +
        '<div class="diagram"><b>Onboarding training</b><span class="arr">-></span><b>Operational efficiency</b><span class="arr">-></span><b>New employees</b></div></div>';
    },
    science: function (c) {
      var cw = 44, ch = 50, g = c.grid, W = g.rows[0].length * cw, H = g.rows.length * ch;
      var letters = g.rows.map(function (r, y) { return r.split("").map(function (l, x) { return '<text x="' + (x * cw + cw / 2) + '" y="' + (y * ch + ch / 2 + 7) + '">' + l + "</text>"; }).join(""); }).join("");
      var loops = g.words.map(function (w) {
        var x = Math.min(w[2], w[4]) * cw + 3, y = Math.min(w[1], w[3]) * ch + 5, ww = (Math.abs(w[4] - w[2]) + 1) * cw - 6, hh = (Math.abs(w[3] - w[1]) + 1) * ch - 10;
        return '<rect class="loop" pathLength="1" x="' + x + '" y="' + y + '" width="' + ww + '" height="' + hh + '" rx="20"/>';
      }).join("");
      return '<div class="olive reveal"><div class="ws"><svg viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="Word search with five words circled in order: plant, gene, data, system, technology" data-hook="ws">' + letters + loops + "</svg>" +
        '<p class="mono ws-cap">plant > gene > data > system > technology</p></div>' +
        '<ol class="items">' + c.items.map(function (t) { return "<li>" + esc(t) + "</li>"; }).join("") + "</ol></div>" + link(c.link);
    },
    creative: function (c) {
      return '<div class="band reveal"><img src="' + c.band.src + '" alt="' + esc(c.band.alt) + '" style="object-position:' + c.band.pos + '" loading="lazy"></div>' + lines(c.lines) +
        label("Contact sheet") + '<div class="sheet reveal">' + c.sheet.map(function (p, i) {
          return '<figure><img src="' + p.src + '" alt="' + esc(p.alt) + '" loading="lazy"><figcaption class="mono">' + ("0" + (i + 1)).slice(-2) + "A</figcaption></figure>";
        }).join("") + "</div>";
    },
    archive: function (c) {
      return '<div class="collage">' + c.collage.map(function (p, i) {
        return '<figure class="snap dev" style="--rot:' + p.rot + '"><span class="tape" aria-hidden="true"></span><img src="' + p.src + '" alt="' + esc(p.alt) + '" loading="lazy"><figcaption class="hand">' + esc(p.note) + "</figcaption></figure>";
      }).join("") + "</div>";
    },
    about: function (c) {
      return label("Skills by system") + '<div class="groups reveal">' + c.groups.map(function (g) {
        return '<button class="group" type="button" data-go="' + g.to + '"><h3>' + esc(g.name) + "</h3><ul>" + g.items.map(function (i) { return "<li>" + esc(i) + "</li>"; }).join("") + '</ul><span class="mono">Open chapter</span></button>';
      }).join("") + "</div>";
    }
  };

  function buildChapter(c) {
    if (c.id === "next") {
      return '<article class="c c-next">' + head(c) + '<p class="mono boot-l" id="nx-boot"></p>' + lines(c.lines) +
        '<div class="status reveal"><p class="label">System status</p><ul><li>Learning</li><li>Building</li><li>Exploring</li></ul><p class="label">File status: in progress</p>' + linkRow() + "</div>" +
        '<p class="final reveal">Thank you for visiting.</p>' + nextBlock(c) + "</article>";
    }
    if (c.id === "contact") {
      return '<article class="c">' + head(c) + '<div class="card reveal"><p class="label">Contact card</p><h3>' + esc(S.name) + "</h3><p>" + esc(S.role) + "<br>Rīga, Latvia</p>" + linkRow() + "</div>" + nextBlock(c) + "</article>";
    }
    var h = '<article class="c c-' + c.id + '" style="--tone:' + c.color + '">' + head(c) + (c.id === "creative" ? "" : lines(c.lines));
    if (special[c.id]) h += special[c.id](c);
    h += facts(c.facts);
    return h + nextBlock(c) + "</article>";
  }

  /* ---------- hooks ---------- */
  async function typeTerminal(el, my) {
    var out = $("#term-out", el); out.innerHTML = "";
    var arr = byId("now").terminal;
    for (var i = 0; i < arr.length; i++) {
      if (my !== run) return;
      var p = document.createElement("p"); out.appendChild(p);
      var t = arr[i];
      if (RM) p.textContent = t; else for (var k = 1; k <= t.length; k++) { p.textContent = t.slice(0, k); await wait(14); if (my !== run) return; }
      if (/loaded$/.test(t)) p.classList.add("ok");
      if (/progress$/.test(t)) p.classList.add("cur");
      await wait(140);
    }
  }
  async function stepEach(nodes, my, gap) { for (var i = 0; i < nodes.length; i++) { if (my !== run) return; nodes[i].classList.add("on"); blip(300 + i * 60, 0.05); await wait(gap || 650); } }
  function countUp(b) {
    var from = +b.dataset.from, to = +b.dataset.to, suf = b.dataset.suffix, t0 = null;
    if (RM) { b.textContent = to + suf; return; }
    (function f(t) { if (!t0) t0 = t; var k = Math.min((t - t0) / 1300, 1); b.textContent = Math.round(from + (to - from) * (1 - Math.pow(1 - k, 3))) + suf; if (k < 1) requestAnimationFrame(f); })(performance.now());
  }
  function hook(el, my) {
    var h = el.dataset.hook;
    if (h === "terminal") typeTerminal(el, my);
    if (h === "flow") stepEach($$(":scope > div", el), my);
    if (h === "ws") stepEach($$(".loop", el), my, 700);
    if (h === "metrics") $$("b", el).forEach(countUp);
  }
  function setupReveals() {
    if (io) io.disconnect();
    var my = run;
    io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); hook(e.target, my); } });
    }, { root: chapterEl, threshold: 0.15 });
    $$(".lr,.reveal,.dev,.doc,[data-hook]", body).forEach(function (el) { if (RM) { el.classList.add("in"); if (el.dataset.hook) hook(el, my); } else io.observe(el); });
  }
  async function bootNext(my) {
    var el = $("#nx-boot"); if (!el) return;
    var t = "> file updated " + new Date().toISOString().slice(0, 10);
    for (var k = 1; k <= t.length; k++) { if (my !== run) return; el.textContent = t.slice(0, k); await wait(22); }
  }

  /* ---------- chapter shell ---------- */
  function trap(e) {
    if (e.key === "Escape") { closeAll(true); return; }
    if (e.key !== "Tab") return;
    var root = recEl.hidden ? chapterEl : recEl;
    var f = $$('button,a[href],[tabindex]:not([tabindex="-1"])', root).filter(function (x) { return !x.disabled && x.offsetParent !== null; });
    if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
  function lock(on) {
    fixed.forEach(function (n) { if (n) n.inert = on; });
    document.body.style.overflow = on ? "hidden" : "";
    document[on ? "addEventListener" : "removeEventListener"]("keydown", trap);
  }
  function render(c) {
    run++;
    chapterEl.classList.toggle("dark", !!c.dark);
    $("#chapter-file").textContent = c.file;
    body.innerHTML = buildChapter(c);
    chapterEl.scrollTop = 0;
    document.title = c.title + " | Shreya Jagtap";
    setupReveals();
    if (c.id === "next") bootNext(run);
  }
  function transition(cb) {
    var t = $("#transition"), bar = $("i", t), pct = $(".pct", t);
    if (RM) { cb(); return; }
    t.className = "transition in"; bar.style.width = "0";
    var t0 = performance.now();
    (function f(now) {
      var k = Math.min(Math.max((now - t0 - 450) / 500, 0), 1);
      bar.style.width = k * 100 + "%"; pct.textContent = Math.round(k * 100) + "%";
      if (k < 1) requestAnimationFrame(f);
      else { cb(); t.className = "transition out"; setTimeout(function () { t.style.transition = "none"; t.className = "transition"; void t.offsetWidth; t.style.transition = ""; }, 600); }
    })(performance.now());
  }
  function showChapter(id) {
    var c = byId(id); if (!c || current === id) return;
    var wasOpen = !chapterEl.hidden;
    if (!wasOpen) lastFocus = document.activeElement;
    transition(function () {
      recEl.hidden = true; chapterEl.hidden = false; current = id;
      if (!wasOpen) lock(true);
      render(c);
      $("#chapter-close").focus({ preventScroll: true });
    });
  }
  function showRecruiter() {
    if (!recEl.hidden) return;
    lastFocus = document.activeElement; chapterEl.hidden = true; current = null;
    var r = S.recruiter;
    $("#recruiter-body").innerHTML =
      '<article class="c"><header class="c-head"><h2 class="name">' + S.name.toUpperCase() + '</h2><p class="mono">Learning & Development Specialist | Rīga, Latvia</p></header>' +
      '<p class="links"><a href="' + S.cv + '" download>Download CV</a><a href="' + S.linkedin + '" rel="noopener">LinkedIn</a><a href="' + S.github + '" rel="noopener">GitHub</a><a href="mailto:' + S.email + '">' + S.email + "</a></p>" +
      "<h2>Professional summary</h2><p style=\"max-width:70ch\">" + r.summary + "</p>" +
      "<h2>Experience</h2>" + r.experience.map(function (j) { return '<div class="job"><b>' + j.role + "</b><span>" + j.org + ", " + j.when + "</span><ul>" + j.points.map(function (p) { return "<li>" + p + "</li>"; }).join("") + "</ul></div>"; }).join("") +
      "<h2>Education</h2>" + r.education.map(function (e) { return '<div class="job"><b>' + e.name + "</b><span>" + e.org + ", " + e.when + "</span></div>"; }).join("") +
      "<h2>Skills</h2>" + r.skills.map(function (s) { return "<p><b>" + s[0] + ":</b> " + s[1] + "</p>"; }).join("") +
      "<h2>Projects</h2><ul>" + r.projects.map(function (p) { return "<li>" + p + "</li>"; }).join("") + "</ul>" +
      "<h2>Achievements</h2><ul>" + r.achievements.map(function (p) { return "<li>" + p + "</li>"; }).join("") + "</ul>" +
      "<h2>Contact</h2><p>" + S.email + "<br>Rīga, Latvia</p></article>";
    recEl.hidden = false; lock(true); document.title = "Recruiter mode | Shreya Jagtap"; $("#recruiter-close").focus({ preventScroll: true }); recEl.scrollTop = 0;
  }
  function closeAll(updateHash) {
    var open = !chapterEl.hidden || !recEl.hidden;
    chapterEl.hidden = true; recEl.hidden = true; current = null; run++;
    if (open) { lock(false); if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true }); }
    document.title = "Shreya Jagtap | Learning & Development, Operations, Training and Technology";
    if (updateHash && location.hash) history.pushState(null, "", location.pathname + location.search);
  }
  function route() {
    var id = location.hash.replace("#", "");
    if (!id) return closeAll(false);
    if (id === "cv") return showRecruiter();
    if (byId(id)) return showChapter(id);
    closeAll(false);
  }
  function go(id) {
    if (id === "home") return closeAll(true);
    if (("#" + id) === location.hash) return route();
    location.hash = id;
  }

  /* ---------- wiring ---------- */
  var menu = $("#chapters-menu");
  document.addEventListener("click", function (e) {
    var g = e.target.closest("[data-go]"); if (g) { e.preventDefault(); menu.hidden = true; blip(480); go(g.dataset.go); return; }
    if (!e.target.closest(".dock")) { menu.hidden = true; $("#btn-chapters").setAttribute("aria-expanded", "false"); }
  });
  $("#chapter-close").addEventListener("click", function () { go("home"); });
  $("#recruiter-close").addEventListener("click", function () { go("home"); });
  $("#btn-recruiter").addEventListener("click", function () { go("cv"); });
  menu.innerHTML = seq.map(function (c, i) { return '<button type="button" data-go="' + c.id + '"><span>' + esc(c.file) + "</span><span>" + ("0" + (i + 1)).slice(-2) + "</span></button>"; }).join("") +
    '<button type="button" data-go="about"><span>About</span><span></span></button>';
  $("#btn-chapters").addEventListener("click", function (e) { e.stopPropagation(); menu.hidden = !menu.hidden; this.setAttribute("aria-expanded", String(!menu.hidden)); });
  window.addEventListener("hashchange", route);
  window.addEventListener("popstate", route);
  route();
})();
