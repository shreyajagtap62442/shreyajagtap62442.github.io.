/*
  CONTENT FILE: edit text here, not in main.js.
  Every fact comes from Shreya's CV or her own brief.
*/
window.SITE = {
  name: "Shreya Jagtap",
  role: "Learning & Development / Operations / Computer Systems",
  email: "shreya.jagtap62442@gmail.com",
  linkedin: "https://www.linkedin.com/in/shreya-jagtap-86491626a",
  github: "https://github.com/shreyajagtap62442",
  cv: "assets/Shreya_Jagtap_Resume.pdf",

  tagline: "A career built across science, business, people and technology.",
  tags: [
    { text: "Learning & Development", color: "#9E3035", x: 9, y: 12 },
    { text: "Plant Genetics", color: "#8A9469", x: 80, y: 11 },
    { text: "Operations", color: "#C98657", x: 14, y: 38 },
    { text: "Computer Systems", color: "#7E9AAE", x: 74, y: 38 }
  ],
  boot: ["System online", "Archive loaded", "{n} folders found"],

  // Story order: current me, back to the beginning, then what comes next.
  chapters: [
    {
      id: "now", file: "NOW.exe", color: "#9E3035", word: "now", title: "Now", kicker: "Current file",
      pos: { x: 19, y: 47, r: -3, d: 18 }, selected: true,
      lines: [
        "I am a Learning & Development professional in Rīga, currently studying for a Master's in Computer Systems at Riga Nordic University.",
        "My background spans plant genetics research, customer operations, corporate training and business management."
      ],
      terminal: [
        "> open shreya_jagtap",
        "science ........ loaded",
        "business ....... loaded",
        "people ......... loaded",
        "training ....... loaded",
        "technology ..... in progress"
      ],
      facts: [
        ["Studying", "Master's in Computer Systems, Riga Nordic University (since 09/2026)"],
        ["Completed", "MBA in Business Management, LBTU, 2026"],
        ["Recent role", "Learning & Development Specialist, TELUS Digital"],
        ["Based in", "Rīga, Latvia"]
      ],
      hero: { src: "assets/photos/portrait-warm.webp", alt: "Portrait of Shreya Jagtap in a black blazer against a terracotta backdrop", style: "polaroid", caption: "Shreya Jagtap" }
    },
    {
      id: "it", file: "SYSTEMS.sys", color: "#4E6A80", word: "systems", title: "Systems", kicker: "Computer Systems, Riga Nordic University",
      pos: { x: 6, y: 58, r: 2, d: 26 },
      lines: [
        "In September 2026 I started a Master's in Computer Systems at Riga Nordic University.",
        "The coursework follows the path from raw data to working software: databases, data processing, visualisation, machine learning and version control."
      ],
      facts: [
        ["Programme", "Master's in Computer Systems, Riga Nordic University"],
        ["Started", "22.09.2026, ongoing"],
        ["Coursework", "Python, SQL and relational databases, NumPy and Pandas, matplotlib and seaborn, scikit-learn, Git and unit testing"]
      ],
      hero: { src: "assets/photos/detail-laptop.webp", alt: "Detail: Shreya's hand on a laptop keyboard", style: "mono", caption: "" }
    },
    {
      id: "telus", file: "TELUS.archive", color: "#6F794F", word: "people", title: "People", kicker: "TELUS Digital, Rīga, 2024 to 2026",
      pos: { x: 73, y: 46, r: 2, d: 22 },
      lines: [
        "At TELUS Digital I moved from customer support into Learning & Development, and then into improving how training was designed and delivered."
      ],
      flow: [
        { step: "Support", role: "Customer Support Specialist", when: "11/2024 to 06/2025", text: "Resolved complex cases and owned escalations for a global digital advertising platform." },
        { step: "Training", role: "Learning & Development Specialist", when: "06/2025 to 06/2026", text: "Delivered onboarding and nesting for 4 cohorts of 15 to 20 agents through a 5-week cycle." },
        { step: "Improvement", role: "Programs and platforms", when: "2025 to 2026", text: "Built SOPs and training workflows, launched a performance recovery program, and co-developed the Fuel iX AI training platform." }
      ],
      metrics: [
        { to: 4, suffix: "", label: "Onboarding cohorts", note: "15 to 20 agents each; all moved into live production" },
        { from: 57, to: 80, suffix: "%", label: "CSAT", note: "Up from 57% in 3 weeks (recovery program)" },
        { from: 70, to: 90, suffix: "%", label: "Support Quality Score", note: "Up from 70% in the same 3 weeks" },
        { to: 12, suffix: "", label: "Agents in the recovery program", note: "Program designed and launched independently" }
      ],
      chips: ["Onboarding", "Instructor-led training", "Performance coaching", "Scenario-based learning", "KPI reporting", "Process improvement", "AI-based training simulations"],
      link: { href: "https://www.telusdigital.com/solutions/fuel-ix/agent-trainer", label: "Fuel iX Agent Trainer" },
      hero: { src: "assets/photos/portrait-bw-cutout.webp", alt: "Black and white portrait of Shreya Jagtap", style: "cutout", caption: "" }
    },
    {
      id: "mba", file: "MBA.pdf", color: "#BA703E", word: "business", title: "Business", kicker: "MBA, Latvia University of Life Sciences and Technologies",
      pos: { x: 88, y: 51, r: -2, d: 16 },
      lines: [
        "The MBA added a business perspective to my work: operations, management, strategy and organisational decision-making."
      ],
      thesis: "Impact of Corporate Onboarding Training on the Operational Efficiency of New Employees",
      facts: [
        ["Degree", "MBA in Business Management (EQF 7)"],
        ["University", "Latvia University of Life Sciences and Technologies (LBTU), Jelgava"],
        ["Years", "09/2024 to 06/2026, completed"]
      ]
    },
    {
      id: "science", file: "PLANT_GENETICS.zip", color: "#6F794F", word: "science", title: "Science", kicker: "Plant genetics, Dobele and Jelgava, 2021 to 2025",
      pos: { x: 77, y: 64, r: 3, d: 28 },
      lines: [
        "My career began in plant science: sustainable agriculture, molecular genetics and laboratory research.",
        "Genetic research was my first experience of analysing a complex system through data."
      ],
      grid: {
        rows: ["PKQRWJMDZBDX", "LHDGENEVAXAQ", "AZMYUROFKWTJ", "NBVSYSTEMCAH", "TWXRMKJPQZUV", "QDFJBVHWXEKY", "YTECHNOLOGYM", "KZWQJXVRDBFP"],
        words: [["PLANT", 0, 0, 4, 0], ["GENE", 1, 3, 1, 6], ["DATA", 0, 10, 3, 10], ["SYSTEM", 3, 3, 3, 8], ["TECHNOLOGY", 6, 1, 6, 10]]
      },
      items: [
        "BSc in Sustainable Agriculture, LBTU, 2021 to 2024",
        "Bachelor's thesis on molecular markers for self-incompatibility in Chaenomeles japonica (Japanese quince), supervised by G. Lācis, PhD",
        "Isolated DNA from 74 Chaenomeles genotypes and screened 33 S-gene markers by PCR, Institute of Horticulture, 2022 to 2023",
        "Co-author, International Journal of Plant Biology, 2025: phenotypic variability of Latvian common bean",
        "Presented at the LBTU student conference (2024, plenary) and Līdzsvarota Lauksaimniecība 2025"
      ],
      link: { href: "https://doi.org/10.3390/ijpb16020059", label: "Read the publication" }
    },
    {
      id: "creative", file: "CREATIVE.lab", color: "#D684A8", word: "creative", title: "Creative", kicker: "Visual storytelling",
      pos: { x: 89, y: 73, r: -3, d: 20 },
      lines: [
        "Alongside my professional work, I work on visual storytelling: photography, fashion and content creation."
      ],
      band: { src: "assets/photos/crouch-full.webp", alt: "Shreya Jagtap crouching beside a laptop, notebook and mug", pos: "50% 18%" },
      sheet: [
        { src: "assets/photos/portrait-bw.webp", alt: "Black and white portrait of Shreya Jagtap" },
        { src: "assets/photos/detail-socks.webp", alt: "Detail: red socks and black loafers" },
        { src: "assets/photos/portrait-warm.webp", alt: "Colour portrait of Shreya Jagtap against a terracotta backdrop" }
      ]
    },
    {
      id: "archive", file: "ARCHIVE", color: "#171717", word: "archive", title: "Archive", kicker: "Early years",
      pos: { x: 71, y: 80, r: -2, d: 14 },
      lines: ["Where the story starts."],
      collage: [
        { src: "assets/photos/child-window.webp", alt: "Childhood photograph: sitting cross-legged on a window ledge", note: "window seat", rot: -4 },
        { src: "assets/photos/child-plant.webp", alt: "Childhood photograph: sitting in front of a large croton plant", note: "in the garden", rot: 3 },
        { src: "assets/photos/child-shelf.webp", alt: "Childhood photograph: smiling from inside a shelf", note: "found a shelf", rot: -2 },
        { src: "assets/photos/child-birthday.webp", alt: "Childhood photograph: flowers in her hair, a birthday cake in front", note: "birthday", rot: 4 }
      ]
    },
    {
      id: "next", file: "NEXT.pkg", color: "#F5F0E7", word: "next", title: "Next", kicker: "File status: in progress", dark: true,
      pos: { x: 86, y: 86, r: 3, d: 12 },
      lines: [
        "Next, I am deepening my work in computer systems, with a focus on technology, problem-solving and how people interact with technology."
      ]
    },
    {
      id: "about", file: "portrait.jpg", thumb: "assets/photos/thumb-portrait.webp", color: "#171717", word: "about", title: "About", kicker: "About", hidden: true,
      pos: { x: 22, y: 66, r: 2, d: 12 },
      lines: [
        "My career has moved across disciplines: plant science, customer operations, learning and development, business management, and now computer systems.",
        "Each stage added a different view of how systems work: biological, organisational and technical."
      ],
      groups: [
        { name: "People", to: "telus", items: ["Training", "Coaching", "Communication", "Facilitation", "Customer experience"] },
        { name: "Business", to: "mba", items: ["Operations", "KPI reporting", "Process improvement", "Stakeholder communication", "Change management"] },
        { name: "Technology", to: "it", items: ["AI-based training solutions", "Digital tools", "Computer systems", "Data analysis"] },
        { name: "Science", to: "science", items: ["Plant genetics", "Molecular biology", "PCR", "Laboratory research"] },
        { name: "Creative", to: "creative", items: ["Storytelling", "Visual content", "Photography", "Content creation"] }
      ]
    },
    {
      id: "contact", file: "CONTACT.vcf", color: "#9E3035", word: "contact", title: "Contact", kicker: "Get in touch", hidden: true, pos: null, lines: []
    }
  ],

  recruiter: {
    summary: "Learning & Development Specialist with hands-on experience delivering end-to-end onboarding, training, and performance coaching in international BPO and customer operations. Designs targeted interventions that move real KPIs. MBA in Business Management, BSc in Sustainable Agriculture, a plant genetics research background, and now a Master's in Computer Systems.",
    experience: [
      { role: "Learning & Development Specialist", org: "TELUS Digital, Rīga", when: "06/2025 to 06/2026", points: [
        "Delivered onboarding and nesting for 4 cohorts of 15 to 20 agents (5-week cycle); all cohorts moved into live production.",
        "Designed and launched a low-performer intervention: CSAT 57% to 80% and Support Quality Score 70% to 90% in 3 weeks.",
        "Co-developed the Fuel iX AI training platform with persona-based scenario simulations.",
        "Built SOPs and training workflows; coached agents on KPIs; worked with QA, SMEs and Operations."
      ]},
      { role: "Customer Support Specialist", org: "TELUS Digital, Rīga", when: "11/2024 to 06/2025", points: [
        "Resolved complex cases and owned escalations for a global digital advertising platform."
      ]},
      { role: "Scientific Research Assistant", org: "LBTU, Jelgava", when: "10/2023 to 11/2023", points: [
        "Research on genetic diversity and agricultural data analysis; laboratory and documentation support."
      ]},
      { role: "Laboratory Technician", org: "Dārzkopības Institūts, Dobele", when: "05/2022 to 08/2023", points: [
        "DNA isolation from 74 genotypes; PCR screening of 33 molecular markers; co-author on a 2025 publication."
      ]}
    ],
    education: [
      { name: "Master's in Computer Systems", org: "Riga Nordic University (RNU)", when: "09/2026 to present" },
      { name: "MBA in Business Management (EQF 7)", org: "LBTU, Jelgava", when: "09/2024 to 06/2026, completed" },
      { name: "BSc in Sustainable Agriculture (EQF 6)", org: "LBTU, Jelgava", when: "09/2021 to 06/2024" }
    ],
    skills: [
      ["Learning & Development", "Onboarding and training, performance coaching, KPI reporting, process improvement, AI-based training solutions, change management"],
      ["Tools", "Google Workspace, Microsoft Office, Workday Learning, Cornerstone, AI training and simulation platforms"],
      ["Research", "DNA isolation, PCR marker screening, phenotyping, ANOVA, PCA, cluster analysis"]
    ],
    projects: [
      "Fuel iX AI training simulation (TELUS Digital, 12/2025 to 01/2026)",
      "Low-performer recovery program (TELUS Digital, 2026)"
    ],
    achievements: [
      "CSAT 57% to 80% and Support Quality Score 70% to 90% in 3 weeks (12 agents)",
      "4 onboarding cohorts, 15 to 20 agents each, all into live production",
      "Co-author, International Journal of Plant Biology, 2025 (DOI 10.3390/ijpb16020059)"
    ]
  }
};
