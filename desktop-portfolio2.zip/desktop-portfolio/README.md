# Shreya Jagtap: Portfolio

An interactive portfolio that behaves like a personal computer. The visitor opens folders (chapters) and moves from the present, back through work, business, science and creative work to early years, then to what comes next.

Recruiters can press **Recruiter mode** (or open `#cv`) for a plain, fast CV view.

## Tech stack
Plain HTML, CSS and JavaScript. No build step and no dependencies, so it runs anywhere and deploys to GitHub Pages as is. Fonts (Inter, IBM Plex Mono, Caveat) load from Google Fonts. For best performance, self-host them later.

The first version was written without a build tool because it had to work without installing packages. It is organised in components (see below) so it can be ported to Next.js or React later.

## Run it
Open `index.html` in a browser, or serve the folder:

    python3 -m http.server 8000

Then visit http://localhost:8000

## Deploy (GitHub Pages)
1. Create a public repository and upload everything in this folder.
2. Settings > Pages > Deploy from branch > `main` / root.
3. Copy the published address and replace `https://YOUR-SITE-URL/` in `index.html` (canonical, og:image and og:url). This is what makes the LinkedIn preview work.
4. Optional: `assets/originals/` holds your untouched photos. Keep them in a private repository if you prefer.

## Edit the content
All text lives in `js/content.js`: one entry per chapter (file name, title, short story lines, facts, photos, folder position on the desktop) plus the Recruiter mode content.

## Titles (crayon lettering)
The crayon words (PORTFOLIO and each chapter title) are images in `assets/type/`, generated so they look identical on every device. To add a new title, ask for a new crayon image or reuse an existing one.

## Replace images
Photos are in `assets/photos/` (optimised WebP). To swap one, save the new file there with the same name, or change the path in `content.js`.
- Originals are never modified: `assets/originals/`.
- `hero-crouch.webp` is a cut-out of the laptop photo for the home page; it is blended onto the paper so the white studio floor disappears.
- Social preview: `assets/og-image.jpg` (1200 x 630).

## Components (all in `js/main.js`)
Desktop and DesktopFolder (folders built from data), Cursor, Boot lines, Chapter shell (window, focus trap, hash routing), ChapterTransition (loading wipe), Typewriter/Terminal, Timeline/Flow, MetricCard (count-up), WordSearch (plant > gene > data > system > technology), PhotoCard, Collage, ContactSheet, Recruiter mode, Sound toggle.

## Animation map
- Home: folders bob at different speeds and depths; cursor moves the portrait and folders (parallax); folder label shows a loading bar on hover.
- Chapters: loading-wipe transition; text lines wipe in; photos develop from blur to sharp; the terminal types itself; metrics count up; the TELUS progression lights up step by step.
- Home: the crayon PORTFOLIO draws itself in from left to right.
- Science: a word search circles PLANT, GENE, DATA, SYSTEM and TECHNOLOGY in order.
- All motion stops when the visitor's system asks for reduced motion.

## Accessibility and performance
Semantic HTML, keyboard navigation (Esc closes a window, Tab is trapped in open windows), visible focus rings, alt text on every image, no information only on hover (handwritten notes are always visible). Images are lazy loaded except the home portrait.

## Sound
Off by default. The toggle plays tiny synthesised clicks. No audio files.

## Routes
The site is one page with hash routes: `#now`, `#it`, `#telus`, `#mba`, `#science`, `#creative`, `#archive`, `#next`, `#about`, `#contact`, `#cv`.
